package com.example.flutter_biodata

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
