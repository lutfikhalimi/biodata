import 'package:flutter/material.dart';

class DetailProfilPage extends StatelessWidget {
  const DetailProfilPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Profil Ku"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(100),
                  child: Image.asset(
                    'assets/photo.png',
                    width: 100,
                  ),
                ),
              ],
            ),
            const Text("Nama: Lutfi Khalimi"),
            const SizedBox(height: 10),
            const Text("Email: lutfikhalimi11@gmail.com"),
            const SizedBox(height: 10),
            const Text("Github: https://github.com/lutfikhalimi/biodata"),
            const SizedBox(height: 10),
            const Text("Nomer HP: 082137854047"),
          ],
        ),
      ),
    );
  }
}
